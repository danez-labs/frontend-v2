var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var constants_exports = {};
__export(constants_exports, {
  BLOCK_TAG_LAG: () => BLOCK_TAG_LAG,
  DEFAULT_QUOTE_TIMESTAMP_BUFFER: () => DEFAULT_QUOTE_TIMESTAMP_BUFFER,
  SUPPORTED_CG_BASE_CURRENCIES: () => SUPPORTED_CG_BASE_CURRENCIES,
  disabledL1Tokens: () => disabledL1Tokens,
  maxRelayFeePct: () => maxRelayFeePct,
  relayerFeeCapitalCostConfig: () => relayerFeeCapitalCostConfig
});
module.exports = __toCommonJS(constants_exports);
var import_ethers = require("ethers");
const maxRelayFeePct = 0.25;
const disabledL1Tokens = [
  "0x3472A5A71965499acd81997a54BBA8D852C6E53d"
].map((x) => x.toLowerCase());
const relayerFeeCapitalCostConfig = {
  ETH: {
    lowerBound: import_ethers.ethers.utils.parseUnits("0.0001").toString(),
    upperBound: import_ethers.ethers.utils.parseUnits("0.0001").toString(),
    cutoff: import_ethers.ethers.utils.parseUnits("750").toString(),
    decimals: 18
  },
  WETH: {
    lowerBound: import_ethers.ethers.utils.parseUnits("0.0001").toString(),
    upperBound: import_ethers.ethers.utils.parseUnits("0.0001").toString(),
    cutoff: import_ethers.ethers.utils.parseUnits("750").toString(),
    decimals: 18
  },
  WBTC: {
    lowerBound: import_ethers.ethers.utils.parseUnits("0.0003").toString(),
    upperBound: import_ethers.ethers.utils.parseUnits("0.0025").toString(),
    cutoff: import_ethers.ethers.utils.parseUnits("10").toString(),
    decimals: 8
  },
  DAI: {
    lowerBound: import_ethers.ethers.utils.parseUnits("0.0001").toString(),
    upperBound: import_ethers.ethers.utils.parseUnits("0.0001").toString(),
    cutoff: import_ethers.ethers.utils.parseUnits("250000").toString(),
    decimals: 18
  },
  USDC: {
    lowerBound: import_ethers.ethers.utils.parseUnits("0.0001").toString(),
    upperBound: import_ethers.ethers.utils.parseUnits("0.0001").toString(),
    cutoff: import_ethers.ethers.utils.parseUnits("1500000").toString(),
    decimals: 6
  },
  UMA: {
    lowerBound: import_ethers.ethers.utils.parseUnits("0.0003").toString(),
    upperBound: import_ethers.ethers.utils.parseUnits("0.00075").toString(),
    cutoff: import_ethers.ethers.utils.parseUnits("5000").toString(),
    decimals: 18
  },
  BADGER: {
    lowerBound: import_ethers.ethers.utils.parseUnits("0.0003").toString(),
    upperBound: import_ethers.ethers.utils.parseUnits("0.001").toString(),
    cutoff: import_ethers.ethers.utils.parseUnits("5000").toString(),
    decimals: 18
  },
  BOBA: {
    lowerBound: import_ethers.ethers.utils.parseUnits("0.0003").toString(),
    upperBound: import_ethers.ethers.utils.parseUnits("0.001").toString(),
    cutoff: import_ethers.ethers.utils.parseUnits("100000").toString(),
    decimals: 18
  }
};
const DEFAULT_QUOTE_TIMESTAMP_BUFFER = 12 * 25;
const BLOCK_TAG_LAG = -1;
const SUPPORTED_CG_BASE_CURRENCIES = /* @__PURE__ */ new Set(["eth", "usd"]);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  BLOCK_TAG_LAG,
  DEFAULT_QUOTE_TIMESTAMP_BUFFER,
  SUPPORTED_CG_BASE_CURRENCIES,
  disabledL1Tokens,
  maxRelayFeePct,
  relayerFeeCapitalCostConfig
});
