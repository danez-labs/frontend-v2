var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var coingecko_exports = {};
__export(coingecko_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(coingecko_exports);
var import_ethers = require("ethers");
var import_typeguards = require("../helpers/_typeguards");
var import_utils = require("../helpers/_utils");
var import_constants = require("../helpers/_constants");
var import_sdk_v2 = require("@across-protocol/sdk-v2");
const { Coingecko } = import_sdk_v2.coingecko;
const { SymbolMapping } = import_sdk_v2.relayFeeCalculator;
const {
  REACT_APP_COINGECKO_PRO_API_KEY,
  FIXED_TOKEN_PRICES,
  REDIRECTED_TOKEN_PRICE_LOOKUP_ADDRESSES
} = process.env;
const getCoingeckoPrices = async (coingeckoClient, tokenAddress, baseCurrency, hardcodedTokenPrices = {}) => {
  const baseCurrencyToken = SymbolMapping[baseCurrency.toUpperCase()];
  if (!baseCurrencyToken)
    throw new import_utils.InputError(`Base currency ${baseCurrency} not supported`);
  if (tokenAddress.toLowerCase() === baseCurrencyToken.address.toLowerCase())
    return 1;
  let basePriceUsd = hardcodedTokenPrices[baseCurrencyToken.address];
  let tokenPriceUsd = hardcodedTokenPrices[tokenAddress];
  const tokenAddressesToFetchPricesFor = [];
  if (basePriceUsd === void 0)
    tokenAddressesToFetchPricesFor.push(baseCurrencyToken.address);
  if (tokenPriceUsd === void 0)
    tokenAddressesToFetchPricesFor.push(tokenAddress);
  const prices = await coingeckoClient.getContractPrices(tokenAddressesToFetchPricesFor, "usd");
  if (prices.length === 0 || prices.length > 2)
    throw new Error("unexpected prices list returned by coingeckoClient");
  if (prices.length === 2)
    [tokenPriceUsd, basePriceUsd] = prices[0].address.toLowerCase() === tokenAddress.toLowerCase() ? [prices[0].price, prices[1].price] : [prices[1].price, prices[0].price];
  else {
    if (basePriceUsd === void 0)
      basePriceUsd = prices[0].price;
    else
      tokenPriceUsd = prices[0].price;
  }
  return Number((tokenPriceUsd / basePriceUsd).toFixed(baseCurrencyToken.decimals));
};
const handler = async (event) => {
  const logger = (0, import_utils.getLogger)();
  let { l1Token, baseCurrency } = event.queryStringParameters || {};
  try {
    if (!(0, import_typeguards.isString)(l1Token))
      throw new import_utils.InputError("Must provide l1Token as query param");
    if (!(0, import_typeguards.isString)(baseCurrency))
      baseCurrency = "eth";
    else
      baseCurrency = baseCurrency.toLowerCase();
    l1Token = import_ethers.ethers.utils.getAddress(l1Token);
    const redirectLookupAddresses = REDIRECTED_TOKEN_PRICE_LOOKUP_ADDRESSES !== void 0 ? JSON.parse(REDIRECTED_TOKEN_PRICE_LOOKUP_ADDRESSES) : {};
    if (redirectLookupAddresses[l1Token]) {
      l1Token = redirectLookupAddresses[l1Token];
    }
    const coingeckoClient = Coingecko.get(logger, REACT_APP_COINGECKO_PRO_API_KEY);
    let price;
    const _fixedTokenPrices = FIXED_TOKEN_PRICES !== void 0 ? JSON.parse(FIXED_TOKEN_PRICES) : {};
    const fixedTokenPrices = Object.fromEntries(Object.entries(_fixedTokenPrices).map(([token, price2]) => [
      import_ethers.ethers.utils.getAddress(token),
      price2
    ]));
    if (fixedTokenPrices[l1Token] !== void 0 && !isNaN(fixedTokenPrices[l1Token])) {
      if (baseCurrency === "usd")
        price = fixedTokenPrices[l1Token];
      else {
        price = await getCoingeckoPrices(coingeckoClient, l1Token, baseCurrency, fixedTokenPrices);
      }
    } else if (import_constants.SUPPORTED_CG_BASE_CURRENCIES.has(baseCurrency)) {
      [, price] = await coingeckoClient.getCurrentPriceByContract(l1Token, baseCurrency);
    } else {
      price = await getCoingeckoPrices(coingeckoClient, l1Token, baseCurrency, fixedTokenPrices);
    }
    return {
      statusCode: 200,
      headers: {
        "Cache-Control": "s-maxage=150, stale-while-revalidate=150"
      },
      body: JSON.stringify({ price })
    };
  } catch (error) {
    return (0, import_utils.handleErrorCondition)("coingecko", logger, error);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
