var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target, mod));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var utils_exports = {};
__export(utils_exports, {
  DEFAULT_GAS_MARKUP: () => DEFAULT_GAS_MARKUP,
  ENABLED_ROUTES: () => ENABLED_ROUTES,
  HUP_POOL_CHAIN_ID: () => HUP_POOL_CHAIN_ID,
  InputError: () => InputError,
  applyFilterMap: () => applyFilterMap,
  applyMapFilter: () => applyMapFilter,
  bobaProvider: () => bobaProvider,
  dummyFromAddress: () => dummyFromAddress,
  gasMarkup: () => gasMarkup,
  getBalance: () => getBalance,
  getCachedTokenPrice: () => getCachedTokenPrice,
  getGasMarkup: () => getGasMarkup,
  getHubPoolClient: () => getHubPoolClient,
  getLogger: () => getLogger,
  getProvider: () => getProvider,
  getRelayerFeeCalculator: () => getRelayerFeeCalculator,
  getRelayerFeeDetails: () => getRelayerFeeDetails,
  getSpokePool: () => getSpokePool,
  getTokenDetails: () => getTokenDetails,
  getTokenSymbol: () => getTokenSymbol,
  handleErrorCondition: () => handleErrorCondition,
  infuraProvider: () => infuraProvider,
  isRouteEnabled: () => isRouteEnabled,
  log: () => log,
  makeHubPoolClientConfig: () => makeHubPoolClientConfig,
  maxBN: () => maxBN,
  minBN: () => minBN,
  overrideProvider: () => overrideProvider,
  providerCache: () => providerCache,
  providerForChain: () => providerForChain,
  queries: () => queries,
  resolveVercelEndpoint: () => resolveVercelEndpoint
});
module.exports = __toCommonJS(utils_exports);
var import_contracts_v2 = require("@across-protocol/contracts-v2");
var import_axios = __toESM(require("axios"));
var sdk = __toESM(require("@across-protocol/sdk-v2"));
var import_ethers = require("ethers");
var import_logging = require("@google-cloud/logging");
var import_routes_1_0xc186fA914353c44b2E33eBE05f21846F1048bEda = __toESM(require("../src/data/routes_1_0xc186fA914353c44b2E33eBE05f21846F1048bEda.json"));
var import_routes_5_0xA44A832B994f796452e4FaF191a041F791AD8A0A = __toESM(require("../src/data/routes_5_0xA44A832B994f796452e4FaF191a041F791AD8A0A.json"));
var import_constants = require("./_constants");
const {
  REACT_APP_HUBPOOL_CHAINID,
  REACT_APP_PUBLIC_INFURA_ID,
  REACT_APP_COINGECKO_PRO_API_KEY,
  REACT_APP_GOOGLE_SERVICE_ACCOUNT,
  VERCEL_ENV,
  GAS_MARKUP,
  DISABLE_DEBUG_LOGS
} = process.env;
const GOOGLE_SERVICE_ACCOUNT = REACT_APP_GOOGLE_SERVICE_ACCOUNT ? JSON.parse(REACT_APP_GOOGLE_SERVICE_ACCOUNT) : {};
const gasMarkup = GAS_MARKUP ? JSON.parse(GAS_MARKUP) : {};
const DEFAULT_GAS_MARKUP = 0;
const HUP_POOL_CHAIN_ID = Number(REACT_APP_HUBPOOL_CHAINID || 1);
const ENABLED_ROUTES = HUP_POOL_CHAIN_ID === 1 ? import_routes_1_0xc186fA914353c44b2E33eBE05f21846F1048bEda.default : import_routes_5_0xA44A832B994f796452e4FaF191a041F791AD8A0A.default;
const log = (gcpLogger, severity, data) => {
  if (DISABLE_DEBUG_LOGS === "true" && severity === "DEBUG") {
    console.log(data);
    return;
  }
  let message = JSON.stringify(data, null, 4);
  gcpLogger.write(gcpLogger.entry({
    resource: {
      type: "global"
    },
    severity
  }, message)).catch((error) => {
    sdk.relayFeeCalculator.DEFAULT_LOGGER.error({
      at: "GCP logger",
      message: "Failed to log to GCP",
      error,
      data
    });
  });
};
let logger;
const getLogger = () => {
  if (Object.keys(GOOGLE_SERVICE_ACCOUNT).length === 0) {
    logger = sdk.relayFeeCalculator.DEFAULT_LOGGER;
  }
  if (!logger) {
    const gcpLogger = new import_logging.Logging({
      projectId: GOOGLE_SERVICE_ACCOUNT.project_id,
      credentials: {
        client_email: GOOGLE_SERVICE_ACCOUNT.client_email,
        private_key: GOOGLE_SERVICE_ACCOUNT.private_key
      }
    }).log(VERCEL_ENV ?? "", { removeCircular: true });
    logger = {
      debug: (data) => log(gcpLogger, "DEBUG", data),
      info: (data) => log(gcpLogger, "INFO", data),
      warn: (data) => log(gcpLogger, "WARN", data),
      error: (data) => log(gcpLogger, "ERROR", data)
    };
  }
  return logger;
};
const resolveVercelEndpoint = () => {
  const url = process.env.VERCEL_URL ?? "across.to";
  const env = process.env.VERCEL_ENV ?? "development";
  switch (env) {
    case "preview":
    case "production":
      return `https://${url}`;
    case "development":
    default:
      return `http://localhost:3000`;
  }
};
const getTokenDetails = async (provider, l1Token, l2Token, chainId) => {
  const hubPool = import_contracts_v2.HubPool__factory.connect(ENABLED_ROUTES.hubPoolAddress, provider);
  const l2TokenFilter = hubPool.filters.SetPoolRebalanceRoute(void 0, l1Token, l2Token);
  const events = (await hubPool.queryFilter(l2TokenFilter, 0, "latest")).filter((event2) => !chainId || event2.args.destinationChainId.toString() === chainId);
  if (events.length === 0)
    throw new InputError("No whitelisted token found");
  events.sort((a, b) => {
    if (b.blockNumber !== a.blockNumber)
      return b.blockNumber - a.blockNumber;
    if (b.transactionIndex !== a.transactionIndex)
      return b.transactionIndex - a.transactionIndex;
    return b.logIndex - a.logIndex;
  });
  const event = events[0];
  return {
    hubPool,
    chainId: event.args.destinationChainId.toNumber(),
    l1Token: event.args.l1Token,
    l2Token: event.args.destinationToken
  };
};
class InputError extends Error {
}
const infuraProvider = (nameOrChainId) => {
  const url = new import_ethers.ethers.providers.InfuraProvider(nameOrChainId, REACT_APP_PUBLIC_INFURA_ID).connection.url;
  return new import_ethers.ethers.providers.StaticJsonRpcProvider(url);
};
const bobaProvider = () => new import_ethers.ethers.providers.StaticJsonRpcProvider("https://mainnet.boba.network");
const overrideProvider = (chainId) => {
  const url = process.env[`OVERRIDE_PROVIDER_${chainId}`];
  if (url) {
    return new import_ethers.ethers.providers.StaticJsonRpcProvider(url);
  } else {
    return void 0;
  }
};
const makeHubPoolClientConfig = (chainId = 1) => {
  return {
    1: {
      chainId: 1,
      hubPoolAddress: "0xc186fA914353c44b2E33eBE05f21846F1048bEda",
      wethAddress: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",
      configStoreAddress: "0x3B03509645713718B78951126E0A6de6f10043f5",
      acceleratingDistributorAddress: "0x9040e41eF5E8b281535a96D9a48aCb8cfaBD9a48",
      merkleDistributorAddress: "0xE50b2cEAC4f60E840Ae513924033E753e2366487"
    },
    5: {
      chainId: 5,
      hubPoolAddress: "0x0e2817C49698cc0874204AeDf7c72Be2Bb7fCD5d",
      wethAddress: "0xB4FBF271143F4FBf7B91A5ded31805e42b2208d6",
      configStoreAddress: "0x3215e3C91f87081757d0c41EF0CB77738123Be83",
      acceleratingDistributorAddress: "0xA59CE9FDFf8a0915926C2AF021d54E58f9B207CC",
      merkleDistributorAddress: "0xF633b72A4C2Fb73b77A379bf72864A825aD35b6D"
    }
  }[chainId];
};
const getHubPoolClient = () => {
  const hubPoolConfig = makeHubPoolClientConfig(HUP_POOL_CHAIN_ID);
  return new sdk.pool.Client(hubPoolConfig, {
    provider: infuraProvider(HUP_POOL_CHAIN_ID)
  }, (_, __) => {
  });
};
const dummyFromAddress = process.env.REACT_APP_DUMMY_FROM_ADDRESS || "0x893d0d70ad97717052e3aa8903d9615804167759";
const getGasMarkup = (chainId) => {
  return gasMarkup[chainId] ?? DEFAULT_GAS_MARKUP;
};
const providerForChain = {
  1: infuraProvider(1),
  10: infuraProvider(10),
  137: infuraProvider(137),
  288: bobaProvider(),
  42161: infuraProvider(42161)
};
const queries = {
  1: () => new sdk.relayFeeCalculator.EthereumQueries(providerForChain[1], void 0, void 0, void 0, void 0, REACT_APP_COINGECKO_PRO_API_KEY, getLogger(), getGasMarkup(1)),
  10: () => new sdk.relayFeeCalculator.OptimismQueries(providerForChain[10], void 0, void 0, void 0, void 0, REACT_APP_COINGECKO_PRO_API_KEY, getLogger(), getGasMarkup(10)),
  137: () => new sdk.relayFeeCalculator.PolygonQueries(providerForChain[137], void 0, void 0, void 0, void 0, REACT_APP_COINGECKO_PRO_API_KEY, getLogger(), getGasMarkup(137)),
  288: () => new sdk.relayFeeCalculator.BobaQueries(providerForChain[288], void 0, void 0, void 0, void 0, REACT_APP_COINGECKO_PRO_API_KEY, getLogger(), getGasMarkup(288)),
  42161: () => new sdk.relayFeeCalculator.ArbitrumQueries(providerForChain[42161], void 0, void 0, void 0, void 0, REACT_APP_COINGECKO_PRO_API_KEY, getLogger(), getGasMarkup(42161))
};
const getRelayerFeeCalculator = (destinationChainId) => {
  const queryFn = queries[destinationChainId];
  if (queryFn === void 0) {
    throw new InputError(`Invalid destination chain Id: ${destinationChainId}`);
  }
  const relayerFeeCalculatorConfig = {
    feeLimitPercent: import_constants.maxRelayFeePct * 100,
    capitalCostsPercent: 0.04,
    queries: queryFn(),
    capitalCostsConfig: import_constants.relayerFeeCapitalCostConfig
  };
  return new sdk.relayFeeCalculator.RelayFeeCalculator(relayerFeeCalculatorConfig, logger);
};
const getTokenSymbol = (tokenAddress) => {
  var _a, _b;
  const symbol = (_b = (_a = Object.entries(sdk.relayFeeCalculator.SymbolMapping)) == null ? void 0 : _a.find(([_symbol, { address }]) => address.toLowerCase() === tokenAddress.toLowerCase())) == null ? void 0 : _b[0];
  if (!symbol) {
    throw new InputError("Token address provided was not whitelisted.");
  }
  return symbol;
};
const getRelayerFeeDetails = (l1Token, amount, destinationChainId, tokenPrice) => {
  const tokenSymbol = getTokenSymbol(l1Token);
  const relayFeeCalculator = getRelayerFeeCalculator(destinationChainId);
  return relayFeeCalculator.relayerFeeDetails(amount, tokenSymbol, tokenPrice);
};
const getCachedTokenPrice = async (l1Token, baseCurrency = "eth") => {
  return Number((await (0, import_axios.default)(`${resolveVercelEndpoint()}/api/coingecko`, {
    params: { l1Token, baseCurrency }
  })).data.price);
};
const providerCache = {};
const getProvider = (_chainId) => {
  const chainId = _chainId.toString();
  if (!providerCache[chainId]) {
    const override = overrideProvider(chainId);
    if (override) {
      providerCache[chainId] = override;
    } else {
      providerCache[chainId] = providerForChain[_chainId];
    }
  }
  return providerCache[chainId];
};
const getSpokePool = (_chainId) => {
  const chainId = _chainId.toString();
  const provider = getProvider(_chainId);
  switch (chainId.toString()) {
    case "1":
      return import_contracts_v2.SpokePool__factory.connect("0x4D9079Bb4165aeb4084c526a32695dCfd2F77381", provider);
    case "10":
      return import_contracts_v2.SpokePool__factory.connect("0xa420b2d1c0841415A695b81E5B867BCD07Dff8C9", provider);
    case "137":
      return import_contracts_v2.SpokePool__factory.connect("0x69B5c72837769eF1e7C164Abc6515DcFf217F920", provider);
    case "288":
      return import_contracts_v2.SpokePool__factory.connect("0xBbc6009fEfFc27ce705322832Cb2068F8C1e0A58", provider);
    case "42161":
      return import_contracts_v2.SpokePool__factory.connect("0xB88690461dDbaB6f04Dfad7df66B7725942FEb9C", provider);
    default:
      throw new Error(`Invalid chainId provided: ${chainId}`);
  }
};
const isRouteEnabled = (fromChainId, toChainId, fromToken) => {
  const enabled = ENABLED_ROUTES.routes.some(({ fromTokenAddress, fromChain, toChain }) => fromChainId === fromChain && toChainId === toChain && fromToken.toLowerCase() === fromTokenAddress.toLowerCase());
  return enabled;
};
const getBalance = (chainId, token, account, blockTag = "latest") => {
  return import_contracts_v2.ERC20__factory.connect(token, getProvider(Number(chainId))).balanceOf(account, { blockTag });
};
const maxBN = (...arr) => {
  return [...arr].sort((a, b) => {
    if (b.gt(a))
      return 1;
    if (a.gt(b))
      return -1;
    return 0;
  })[0];
};
const minBN = (...arr) => {
  return [...arr].sort((a, b) => {
    if (a.gt(b))
      return 1;
    if (b.gt(a))
      return -1;
    return 0;
  })[0];
};
function applyFilterMap(array, filterFn, mappingFn) {
  return array.reduce((accumulator, currentValue) => {
    if (filterFn(currentValue)) {
      accumulator.push(mappingFn(currentValue));
    }
    return accumulator;
  }, []);
}
function applyMapFilter(array, filterFn, mappingFn) {
  return array.reduce((accumulator, currentValue) => {
    const currentValueMapping = mappingFn(currentValue);
    if (filterFn(currentValueMapping)) {
      accumulator.push(currentValueMapping);
    }
    return accumulator;
  }, []);
}
function handleErrorCondition(endpoint, logger2, error) {
  if (!(error instanceof Error)) {
    return {
      statusCode: 500,
      body: "Error could not be defined."
    };
  }
  let status;
  if (error instanceof InputError) {
    logger2.warn({ at: endpoint, message: "400 input error", error });
    status = 400;
  } else {
    logger2.error({ at: endpoint, message: "500 server error", error });
    status = 500;
  }
  return {
    statusCode: status,
    body: error.message
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  DEFAULT_GAS_MARKUP,
  ENABLED_ROUTES,
  HUP_POOL_CHAIN_ID,
  InputError,
  applyFilterMap,
  applyMapFilter,
  bobaProvider,
  dummyFromAddress,
  gasMarkup,
  getBalance,
  getCachedTokenPrice,
  getGasMarkup,
  getHubPoolClient,
  getLogger,
  getProvider,
  getRelayerFeeCalculator,
  getRelayerFeeDetails,
  getSpokePool,
  getTokenDetails,
  getTokenSymbol,
  handleErrorCondition,
  infuraProvider,
  isRouteEnabled,
  log,
  makeHubPoolClientConfig,
  maxBN,
  minBN,
  overrideProvider,
  providerCache,
  providerForChain,
  queries,
  resolveVercelEndpoint
});
